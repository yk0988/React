import './App.css';
import {useState,useRef} from 'react';

function BadInput(){
  const [name, setName] = useState("Guest 👋");
  const [inputValue, setInputValue] = useState("");

  const handleInputChange = (event) => {
    console.log(event.target.value);
    setInputValue(event.target.value);
  };

  const handleChangeName = () => {
    setName(inputValue + " 😊");
  };

  return (
    <div className="BadInput">
      <input type="text" value={inputValue} onChange={handleInputChange} placeholder="이름을 입력하세요 ✍️" />
      <button onClick={handleChangeName}>send 📤</button>
      <h2>Hello, {name}!</h2>
    </div>
  );
}



function GoodInput() {

  const [name, setName] = useState("Guest");
  const inputRef = useRef("");
  
  const refChange = () => {
    setName (inputRef.current.value);
  }

  return (
    <div className="GoodInput">

    <input type="text" ref={inputRef} onChange={refChange}></input>

    <h1>안녕하세요. {name}님!</h1>

    </div>
  );
}


function App(){
 return(
    <div className='App'>
      <BadInput/>
    </div>

 );
}

export default App;
