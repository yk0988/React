import { useState } from 'react';
import './App.css';

function Child(props) {
  
  const [papamoney, setPapamoney] = useState(0);
  const [money, setMoney] = useState(0);

  const getMoney = () => {
    setMoney(money + 5);
  }

  return (
    <div className="Child">
      <h1>여기는 {props.name}의 지갑 입니다. 👶</h1>
      <button onClick={getMoney}>용돈 주세요 💰</button>
      <p>용돈을 {money}만큼 받았습니다. 🎉</p>
      <p>아빠의 월급 {props.papamoney - money} 만원 되었습니다. 💳</p>

      <hr />
    </div>
  );
}

function App() {
  
  const [papamoney, setPapamoney] = useState(0);

  const getSalary = () => {
    setPapamoney(papamoney + 700);
  }
  
  return (
    <div className="App">
      <h1>여기는 아빠의 통장 입니다. 👨‍👧‍👦</h1>
      <button onClick={getSalary}>아빠 월급날 💵</button>
      <p>월급 계좌의 잔액은 {papamoney}만원 입니다. 💳</p>
      <hr />
      <Child papamoney={papamoney} name="첫째" />
      <Child papamoney={papamoney} name="둘째" />
    </div>
  );
}

export default App;
