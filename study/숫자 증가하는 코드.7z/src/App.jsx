import './App.css';
import {useState} from 'react';

function App() {

  const [number, setNumber] = useState(100);

  const btnClick = () => {
    
    setNumber(number+1);
    console.log("number: ", number);
  }
  return (
    <div className="App">
      <button onClick = {btnClick}> plus one</button>
      <h1>{number}</h1>
    </div>
  );
}

export default App;